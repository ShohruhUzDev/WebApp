namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       

        private static void Swap( TextBox textBox, TextBox textBox1)
        {
           

            string s1=textBox.Text;
            string s2 = textBox1.Text;


            string s3;
            s3 = s1;
            s1 = s2;
            s2 = s3;

            textBox.Text = s1;
            textBox1.Text = s2;
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Action<TextBox, TextBox> funk = Swap;//delegate
 
            funk(textBox1, textBox2);

         

        }
    }
}